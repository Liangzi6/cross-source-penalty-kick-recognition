Frozen source-only protocol. All scripts use SEED = 42 and class order Left, Center, Right.
