"""Paired target-group bootstrap for saved prediction probabilities."""
from __future__ import annotations
import argparse
from pathlib import Path
import numpy as np
import pandas as pd
from sklearn.metrics import f1_score

SEED = 42

def macro_f1(table):
    return f1_score(table.true_label_index, table.predicted_label_index, average="macro", labels=[0,1,2], zero_division=0)

def run(path: Path, output_dir: Path, model_a: str, model_b: str):
    table = pd.read_csv(path)
    if "model" not in table.columns or "split_group_id" not in table.columns:
        raise ValueError("prediction file needs model and split_group_id columns")
    groups = table.split_group_id.dropna().unique()
    rng = np.random.default_rng(SEED)
    deltas = []
    for _ in range(10000):
        sampled = rng.choice(groups, size=len(groups), replace=True)
        rows = pd.concat([table[table.split_group_id == group] for group in sampled], ignore_index=True)
        a = rows[rows.model == model_a]
        b = rows[rows.model == model_b]
        deltas.append(macro_f1(a) - macro_f1(b))
    output_dir.mkdir(parents=True, exist_ok=True)
    np.savetxt(output_dir / "paired_bootstrap_deltas.csv", np.asarray(deltas), delimiter=",", header="delta_macro_f1", comments="")
    print({"model_a": model_a, "model_b": model_b, "seed": SEED, "draws": 10000, "delta": float(macro_f1(table[table.model == model_a]) - macro_f1(table[table.model == model_b]))})

if __name__ == "__main__":
    parser = argparse.ArgumentParser()
    parser.add_argument("--prediction-file", type=Path, required=True)
    parser.add_argument("--output-dir", type=Path, default=Path("outputs/statistics"))
    parser.add_argument("--model-a", default="Frozen Late Fusion")
    parser.add_argument("--model-b", default="Pose-only B1")
    args = parser.parse_args()
    run(args.prediction_file, args.output_dir, args.model_a, args.model_b)
