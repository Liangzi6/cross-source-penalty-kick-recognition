"""Pose B1 source-internal grouped OOF and complete-source evaluation."""
from __future__ import annotations
import argparse
from pathlib import Path
import pandas as pd
from common import locked_splits, fit_classifier, metrics, SEED

def main(data_dir: Path, output_dir: Path):
    table = pd.read_csv(data_dir / "keypoints_17coco.csv")
    feature_columns = [c for c in table.columns if c.startswith("kp") and (c.endswith("_x_norm") or c.endswith("_y_norm") or c.endswith("_conf"))]
    rows = []
    for source, fold, train_idx, val_idx in locked_splits(table):
        scaler, classifier = fit_classifier(table.loc[train_idx, feature_columns], table.loc[train_idx, "label_index"])
        probabilities = classifier.predict_proba(scaler.transform(table.loc[val_idx, feature_columns]))
        for record_id, y, probability in zip(table.loc[val_idx, "record_id"], table.loc[val_idx, "label_index"], probabilities):
            rows.append({"record_id": record_id, "source": source, "source_internal_fold": fold, "true_label_index": int(y), "p_left": probability[0], "p_center": probability[1], "p_right": probability[2], "model": "Pose B1", "evaluation_scope": "source_internal_oof"})
    output_dir.mkdir(parents=True, exist_ok=True)
    pd.DataFrame(rows).to_csv(output_dir / "pose_b1_source_internal_oof_probabilities.csv", index=False)
    print({"rows": len(rows), "seed": SEED})

if __name__ == "__main__":
    parser = argparse.ArgumentParser()
    parser.add_argument("--data-dir", type=Path, default=Path("data_derived"))
    parser.add_argument("--output-dir", type=Path, default=Path("outputs/pose_b1"))
    args = parser.parse_args()
    main(args.data_dir, args.output_dir)
