from __future__ import annotations
from pathlib import Path
import numpy as np
import pandas as pd
from sklearn.linear_model import LogisticRegression
from sklearn.metrics import accuracy_score, f1_score
from sklearn.model_selection import StratifiedGroupKFold
from sklearn.preprocessing import StandardScaler

SEED = 42
CLASS_ORDER = ("Left", "Center", "Right")

def locked_splits(table: pd.DataFrame):
    """Yield the locked folds and verify that groups never cross folds."""
    for source, subset in table.groupby("source", sort=True):
        group_owner = subset.groupby("split_group_id")["source_internal_fold"].nunique()
        if group_owner.max() != 1:
            raise ValueError(f"group leakage in {source}")
        for fold in sorted(subset.source_internal_fold.unique()):
            validation = subset.index[subset.source_internal_fold == fold].to_numpy()
            training = subset.index[subset.source_internal_fold != fold].to_numpy()
            yield source, int(fold), training, validation

def verify_recomputed_splits(table: pd.DataFrame):
    splitter = StratifiedGroupKFold(n_splits=5, shuffle=True, random_state=SEED)
    for source, subset in table.groupby("source", sort=True):
        for train, validation in splitter.split(subset, subset.label_index, subset.split_group_id):
            train_groups = set(subset.iloc[train].split_group_id)
            validation_groups = set(subset.iloc[validation].split_group_id)
            assert train_groups.isdisjoint(validation_groups)

def fit_classifier(x_train, y_train):
    scaler = StandardScaler().fit(x_train)
    classifier = LogisticRegression(max_iter=2000, class_weight="balanced", random_state=SEED)
    classifier.fit(scaler.transform(x_train), y_train)
    return scaler, classifier

def metrics(y_true, y_pred):
    return {"accuracy": accuracy_score(y_true, y_pred), "macro_f1": f1_score(y_true, y_pred, average="macro", labels=[0,1,2], zero_division=0)}
