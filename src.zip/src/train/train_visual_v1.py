"""Visual V1 source-internal grouped OOF and complete-source evaluation."""
from __future__ import annotations
import argparse
from pathlib import Path
import pandas as pd
from common import locked_splits, fit_classifier, SEED

def main(data_dir: Path, output_dir: Path):
    index = pd.read_csv(data_dir / "record_id_index.csv")
    embeddings = pd.read_csv(data_dir / "embeddings_resnet18_512d.csv")
    table = index.merge(embeddings, on="record_id", validate="one_to_one")
    feature_columns = [f"embedding_{i:03d}" for i in range(512)]
    rows = []
    for source, fold, train_idx, val_idx in locked_splits(table):
        scaler, classifier = fit_classifier(table.loc[train_idx, feature_columns], table.loc[train_idx, "label_index"])
        probabilities = classifier.predict_proba(scaler.transform(table.loc[val_idx, feature_columns]))
        for record_id, y, probability in zip(table.loc[val_idx, "record_id"], table.loc[val_idx, "label_index"], probabilities):
            rows.append({"record_id": record_id, "source": source, "source_internal_fold": fold, "true_label_index": int(y), "p_left": probability[0], "p_center": probability[1], "p_right": probability[2], "model": "Visual V1", "evaluation_scope": "source_internal_oof"})
    output_dir.mkdir(parents=True, exist_ok=True)
    pd.DataFrame(rows).to_csv(output_dir / "visual_v1_source_internal_oof_probabilities.csv", index=False)
    print({"rows": len(rows), "seed": SEED})

if __name__ == "__main__":
    parser = argparse.ArgumentParser()
    parser.add_argument("--data-dir", type=Path, default=Path("data_derived"))
    parser.add_argument("--output-dir", type=Path, default=Path("outputs/visual_v1"))
    args = parser.parse_args()
    main(args.data_dir, args.output_dir)
