"""Fit a frozen source-only classifier and evaluate the complete other source."""
from __future__ import annotations
import argparse
from pathlib import Path
import pandas as pd
from common import fit_classifier, SEED

def run(data_dir: Path, output_dir: Path, modality: str, train_source: str, target_source: str):
    index = pd.read_csv(data_dir / "record_id_index.csv")
    if modality == "pose":
        table = pd.read_csv(data_dir / "keypoints_17coco.csv")
        feature_columns = [c for c in table.columns if c.startswith("kp") and (c.endswith("_x_norm") or c.endswith("_y_norm") or c.endswith("_conf"))]
    elif modality == "visual":
        table = index.merge(pd.read_csv(data_dir / "embeddings_resnet18_512d.csv"), on="record_id", validate="one_to_one")
        feature_columns = [f"embedding_{i:03d}" for i in range(512)]
    else:
        raise ValueError("modality must be pose or visual")
    source = table[table.source == train_source]
    target = table[table.source == target_source]
    scaler, classifier = fit_classifier(source[feature_columns], source.label_index)
    probabilities = classifier.predict_proba(scaler.transform(target[feature_columns]))
    result = target[["record_id", "source", "label", "label_index"]].copy()
    result["train_source"] = train_source
    result["target_source"] = target_source
    result["p_left"] = probabilities[:, 0]
    result["p_center"] = probabilities[:, 1]
    result["p_right"] = probabilities[:, 2]
    result["predicted_label_index"] = probabilities.argmax(axis=1)
    result["model"] = "Pose B1" if modality == "pose" else "Visual V1"
    result["evaluation_scope"] = "cross_source"
    output_dir.mkdir(parents=True, exist_ok=True)
    result.to_csv(output_dir / f"{modality}_{train_source}_to_{target_source}.csv", index=False)
    print({"modality": modality, "train_source": train_source, "target_source": target_source, "rows": len(result), "seed": SEED})

if __name__ == "__main__":
    parser = argparse.ArgumentParser()
    parser.add_argument("--data-dir", type=Path, default=Path("data_derived"))
    parser.add_argument("--output-dir", type=Path, default=Path("outputs/cross_source"))
    parser.add_argument("--modality", choices=["pose", "visual"], required=True)
    parser.add_argument("--train-source", choices=["YouTube", "NewSelfie"], required=True)
    parser.add_argument("--target-source", choices=["YouTube", "NewSelfie"], required=True)
    args = parser.parse_args()
    if args.train_source == args.target_source:
        raise SystemExit("train-source and target-source must differ")
    run(args.data_dir, args.output_dir, args.modality, args.train_source, args.target_source)
