"""Evaluate saved three-class probabilities with fixed Left/Center/Right order."""
from __future__ import annotations
import argparse
from pathlib import Path
import numpy as np
import pandas as pd
from sklearn.metrics import accuracy_score, confusion_matrix, f1_score, precision_recall_fscore_support

SEED = 42

def evaluate(path: Path):
    table = pd.read_csv(path)
    probability_columns = ["p_left", "p_center", "p_right"]
    probabilities = table[probability_columns].to_numpy(float)
    if not np.allclose(probabilities.sum(axis=1), 1.0, atol=1e-6):
        raise ValueError(f"probability rows do not sum to one: {path}")
    y_true = table.true_label_index.to_numpy(int)
    y_pred = probabilities.argmax(axis=1)
    cm = confusion_matrix(y_true, y_pred, labels=[0, 1, 2])
    precision, recall, f1, support = precision_recall_fscore_support(y_true, y_pred, labels=[0,1,2], zero_division=0)
    metrics = {"file": path.name, "n": len(table), "accuracy": accuracy_score(y_true, y_pred), "macro_f1": f1_score(y_true, y_pred, average="macro", labels=[0,1,2], zero_division=0), "weighted_f1": f1_score(y_true, y_pred, average="weighted", labels=[0,1,2], zero_division=0)}
    per_class = pd.DataFrame({"class": ["Left", "Center", "Right"], "precision": precision, "recall": recall, "f1": f1, "support": support})
    confusion = pd.DataFrame(cm, index=["true_Left", "true_Center", "true_Right"], columns=["pred_Left", "pred_Center", "pred_Right"])
    return metrics, per_class, confusion

if __name__ == "__main__":
    parser = argparse.ArgumentParser()
    parser.add_argument("--prediction-dir", type=Path, default=Path("data_derived/predictions"))
    parser.add_argument("--output-dir", type=Path, default=Path("outputs/metrics"))
    args = parser.parse_args()
    args.output_dir.mkdir(parents=True, exist_ok=True)
    summaries, per_class, matrices = [], [], []
    for path in sorted(args.prediction_dir.glob("*.csv")):
        if not {"true_label_index", "p_left", "p_center", "p_right"}.issubset(pd.read_csv(path, nrows=0).columns):
            continue
        metrics, classes, matrix = evaluate(path)
        summaries.append(metrics)
        classes.insert(0, "file", path.name)
        per_class.append(classes)
        matrix.insert(0, "file", path.name)
        matrices.append(matrix)
    pd.DataFrame(summaries).to_csv(args.output_dir / "metrics.csv", index=False)
    if per_class: pd.concat(per_class, ignore_index=True).to_csv(args.output_dir / "per_class_metrics.csv", index=False)
    if matrices: pd.concat(matrices, ignore_index=True).to_csv(args.output_dir / "confusion_matrices.csv", index=False)
