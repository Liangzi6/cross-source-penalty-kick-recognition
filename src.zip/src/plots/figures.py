"""Produce paper figures and statistical charts from derived features and saved predictions."""
from __future__ import annotations
import argparse
from pathlib import Path
import numpy as np
import pandas as pd
import matplotlib.pyplot as plt
from sklearn.metrics import f1_score

SEED = 42
plt.rcParams.update({"figure.dpi": 120, "savefig.dpi": 300, "font.size": 9})

def save(fig, path):
    path.parent.mkdir(parents=True, exist_ok=True)
    fig.savefig(path, dpi=300, bbox_inches="tight")
    plt.close(fig)

def figure_1(out):
    fig, ax = plt.subplots(figsize=(8, 4))
    ax.axis("off")
    stages = ["Data and\nleakage audit", "Pose\nevidence", "Visual\nevidence", "Probability\nrecovery", "Locked target\nevaluation", "Failure\ndiagnosis"]
    x = np.linspace(0.08, 0.92, 3)
    for i, label in enumerate(stages):
        row, col = divmod(i, 3)
        xx, yy = x[col], 0.72 if row == 0 else 0.27
        ax.text(xx, yy, label, ha="center", va="center", transform=ax.transAxes, bbox={"boxstyle": "round,pad=0.6", "facecolor": "#e8eef3", "edgecolor": "#778899"})
    save(fig, out / "Figure 1.png")

def figure_2(index, out):
    counts = index.groupby(["source", "label"]).size().unstack(fill_value=0).reindex(columns=["Left", "Center", "Right"])
    fig, ax = plt.subplots(figsize=(7, 4)); counts.plot(kind="bar", ax=ax, color=["#1f77b4", "#e6a700", "#d95f02"])
    ax.set_ylabel("Images"); ax.set_xlabel(""); ax.legend(title="Class"); save(fig, out / "Figure 2.png")

def figure_3(pose, out):
    summary = pose.groupby("source").agg(pose_success=("pose_success", "mean"), mean_confidence=("avg_keypoint_conf", "mean"), multi_person=("person_count", lambda x: (x > 1).mean()))
    fig, ax = plt.subplots(figsize=(7, 4)); summary.plot(kind="bar", ax=ax); ax.set_ylim(0, 1.05); ax.set_ylabel("Rate / mean confidence"); ax.set_xlabel(""); save(fig, out / "Figure 3.png")

def prediction_summary(prediction_dir):
    rows = []
    for path in prediction_dir.glob("*.csv"):
        table = pd.read_csv(path)
        if not {"true_label_index", "p_left", "p_center", "p_right"}.issubset(table.columns): continue
        table["predicted_label_index"] = table[["p_left", "p_center", "p_right"]].to_numpy().argmax(axis=1)
        table["file"] = path.name
        rows.append(table)
    return pd.concat(rows, ignore_index=True) if rows else pd.DataFrame()

def statistical_figures(index, pose, prediction_dir, out):
    table = prediction_summary(prediction_dir)
    if table.empty: return
    grouped = table.groupby("file").apply(lambda g: pd.Series({"accuracy": (g.true_label_index == g.predicted_label_index).mean()}), include_groups=False)
    fig, ax = plt.subplots(figsize=(8, 4)); grouped.sort_values("accuracy").plot(kind="bar", ax=ax, color="#2878b5"); ax.set_ylabel("Accuracy"); ax.set_xlabel(""); save(fig, out / "Figure 4.png")
    class_rows = []
    for file, group in table.groupby("file"):
        for cls, name in enumerate(["Left", "Center", "Right"]):
            tp = ((group.true_label_index == cls) & (group.predicted_label_index == cls)).sum()
            precision = tp / max((group.predicted_label_index == cls).sum(), 1)
            recall = tp / max((group.true_label_index == cls).sum(), 1)
            class_rows.append({"file": file, "class": name, "f1": 2 * precision * recall / max(precision + recall, 1e-12)})
    class_table = pd.DataFrame(class_rows)
    pivot = class_table.pivot(index="file", columns="class", values="f1")
    fig, ax = plt.subplots(figsize=(9, 4)); pivot.plot(kind="bar", ax=ax); ax.set_ylabel("F1"); ax.set_xlabel(""); save(fig, out / "Figure 5.png")
    center = table[table.true_label_index == 1].groupby("file")["p_center"].mean()
    fig, ax = plt.subplots(figsize=(8, 4)); center.plot(kind="bar", ax=ax, color="#e6a700"); ax.set_ylabel("Mean P(Center)"); ax.set_xlabel(""); save(fig, out / "Figure 9.png")
    ece_rows = []
    for file, group in table.groupby("file"):
        confidence = group[["p_left", "p_center", "p_right"]].to_numpy().max(axis=1)
        correct = (group.true_label_index.to_numpy() == group.predicted_label_index.to_numpy()).astype(float)
        ece_rows.append({"file": file, "ece": abs(confidence.mean() - correct.mean())})
    ece = pd.DataFrame(ece_rows).set_index("file")
    fig, ax = plt.subplots(figsize=(8, 4)); ece.plot(kind="bar", ax=ax, color="#2a9d8f"); ax.set_ylabel("Diagnostic calibration gap"); ax.set_xlabel(""); save(fig, out / "Figure 10.png")

def remaining_figures(index, pose, prediction_dir, out):
    table = prediction_summary(prediction_dir)
    grouped = table.groupby("file").size() if not table.empty else pd.Series(dtype=float)
    values = [
        (6, "Per-class cross-source F1", "F1", table.groupby("file").apply(lambda g: f1_score(g.true_label_index, g.predicted_label_index, average="macro", labels=[0,1,2], zero_division=0), include_groups=False) if not table.empty else pd.Series()),
        (7, "Hard-label correctness patterns", "Count", pd.Series({"both_correct": int((table.true_label_index == table.predicted_label_index).sum())}) if not table.empty else pd.Series()),
        (11, "Source-side OOF result summary", "Rows", grouped),
        (13, "Mean keypoint confidence by source", "Mean confidence", pose.groupby("source").mean(numeric_only=True).filter(regex="_conf$").mean(axis=1) if not pose.empty else pd.Series()),
        (14, "Source composition diagnostic", "Images", index.source.value_counts()),
        (15, "Fold allocation", "Records", index.groupby(["source", "source_internal_fold"]).size() if not index.empty else pd.Series()),
        (16, "Saved probability file coverage", "Rows", grouped),
    ]
    for number, title, ylabel, series in values:
        fig, ax = plt.subplots(figsize=(8, 4))
        if len(series): series.plot(kind="bar", ax=ax, color="#2878b5")
        ax.set_title(title); ax.set_ylabel(ylabel); ax.set_xlabel("")
        save(fig, out / f"Figure {number}.png")
    stats_path = prediction_dir.parent / "statistics" / "round49_bootstrap_summary_10000.csv"
    if stats_path.exists():
        stats = pd.read_csv(stats_path)
        fig, ax = plt.subplots(figsize=(8, 4)); stats.plot(x="comparison", y="delta_macro_f1", kind="barh", ax=ax, legend=False, color="#c05408"); ax.set_xlabel("Delta Macro-F1"); save(fig, out / "Figure 8.png")
    else:
        fig, ax = plt.subplots(figsize=(8, 4)); ax.axis("off"); save(fig, out / "Figure 8.png")
    fig, ax = plt.subplots(figsize=(8, 4)); ax.axis("off"); ax.text(.5, .5, "Data audit -> pose -> visual -> locked evaluation -> diagnosis", ha="center", va="center"); save(fig, out / "Figure 12.png")

def main(data_dir, prediction_dir, output_dir):
    output_dir.mkdir(parents=True, exist_ok=True)
    index = pd.read_csv(data_dir / "record_id_index.csv")
    pose = pd.read_csv(data_dir / "keypoints_17coco.csv")
    figure_1(output_dir); figure_2(index, output_dir); figure_3(pose, output_dir)
    statistical_figures(index, pose, prediction_dir, output_dir)
    remaining_figures(index, pose, prediction_dir, output_dir)

if __name__ == "__main__":
    parser = argparse.ArgumentParser()
    parser.add_argument("--data-dir", type=Path, default=Path("data_derived"))
    parser.add_argument("--prediction-dir", type=Path, default=Path("data_derived/predictions"))
    parser.add_argument("--output-dir", type=Path, default=Path("outputs/figures"))
    args = parser.parse_args()
    main(args.data_dir, args.prediction_dir, args.output_dir)
