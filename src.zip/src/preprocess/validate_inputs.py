"""Validate the de-identified derived feature tables and locked folds."""
from __future__ import annotations
import argparse
from pathlib import Path
import json
import numpy as np
import pandas as pd

SEED = 42
CLASS_ORDER = ("Left", "Center", "Right")

def validate(data_dir: Path, config_path: Path) -> dict:
    index = pd.read_csv(data_dir / "record_id_index.csv")
    folds = pd.read_csv(data_dir / "folds_groups.csv")
    pose = pd.read_csv(data_dir / "keypoints_17coco.csv")
    embeddings = pd.read_csv(data_dir / "embeddings_resnet18_512d.csv")
    assert index.record_id.is_unique
    assert len(index) == 4746
    assert set(index.label.unique()) <= set(CLASS_ORDER)
    assert set(index.label_index.unique()) == {0, 1, 2}
    assert len(folds) == len(index)
    assert set(folds.record_id) == set(index.record_id)
    assert len(pose) == len(index)
    assert set(pose.record_id) == set(index.record_id)
    assert embeddings.record_id.is_unique and len(embeddings) == len(index)
    assert embeddings.filter(regex=r"^embedding_").shape[1] == 512
    for source, group in folds.groupby("source"):
        owners = group.groupby("split_group_id").source_internal_fold.nunique()
        assert owners.max() == 1, f"group leakage in {source}"
        assert set(group.source_internal_fold) == {1, 2, 3, 4, 5}
    return {"records": len(index), "pose_rows": len(pose), "embedding_rows": len(embeddings), "seed": SEED}

if __name__ == "__main__":
    parser = argparse.ArgumentParser()
    parser.add_argument("--data-dir", type=Path, default=Path("data_derived"))
    parser.add_argument("--config", type=Path, default=Path("configs/protocol.json"))
    args = parser.parse_args()
    print(json.dumps(validate(args.data_dir, args.config), indent=2))
