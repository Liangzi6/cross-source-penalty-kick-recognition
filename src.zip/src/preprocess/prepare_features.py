"""Create fold-safe matrices from the de-identified feature tables."""
from __future__ import annotations
import argparse
from pathlib import Path
import numpy as np
import pandas as pd

SEED = 42

def load_pose(data_dir: Path):
    table = pd.read_csv(data_dir / "keypoints_17coco.csv")
    feature_columns = [c for c in table.columns if c.startswith("kp") and (c.endswith("_x_norm") or c.endswith("_y_norm") or c.endswith("_conf"))]
    return table, feature_columns, table[feature_columns].to_numpy(dtype=np.float32)

def load_visual(data_dir: Path):
    table = pd.read_csv(data_dir / "embeddings_resnet18_512d.csv")
    feature_columns = [f"embedding_{i:03d}" for i in range(512)]
    return table, feature_columns, table[feature_columns].to_numpy(dtype=np.float32)

if __name__ == "__main__":
    parser = argparse.ArgumentParser()
    parser.add_argument("--data-dir", type=Path, default=Path("data_derived"))
    args = parser.parse_args()
    pose, pose_columns, pose_x = load_pose(args.data_dir)
    visual, visual_columns, visual_x = load_visual(args.data_dir)
    print({"pose_shape": pose_x.shape, "visual_shape": visual_x.shape, "seed": SEED})
